// Content script for Social Mindful Usage Extension - Multi-platform support

let sessionStartTime = null;
let timeLimit = null;
let countdownInterval = null;
let isInitialized = false;
let currentPlatform = null;

// Platform detection
function detectPlatform() {
  const hostname = window.location.hostname;

  if (hostname.includes('facebook.com')) return 'facebook';
  else if (hostname.includes('instagram.com')) return 'instagram';
  else if (hostname.includes('tiktok.com')) return 'tiktok';
  else if (hostname.includes('twitter.com') || hostname.includes('x.com')) return 'twitter';
  else if (hostname.includes('youtube.com')) return 'youtube';
  else if (hostname.includes('reddit.com')) return 'reddit';
  else if (hostname.includes('linkedin.com')) return 'linkedin';
  else if (hostname.includes('snapchat.com')) return 'snapchat';
  else if (hostname.includes('pinterest.com')) return 'pinterest';
  else if (hostname.includes('web.whatsapp.com')) return 'whatsapp';
  else if (hostname.includes('discord.com')) return 'discord';

  return null;
}

function getPlatformIcon(platform) {
  const icons = {
    facebook: '👍',
    instagram: '📷',
    tiktok: '🎵',
    twitter: '𝕏',
    youtube: '▶️',
    reddit: '🔴',
    linkedin: '💼',
    snapchat: '👻',
    pinterest: '📌',
    whatsapp: '💬',
    discord: '🎮'
  };
  return icons[platform] || '📱';
}

function getPlatformName(platform) {
  const names = {
    facebook: 'Facebook',
    instagram: 'Instagram',
    tiktok: 'TikTok',
    twitter: 'Twitter/X',
    youtube: 'YouTube',
    reddit: 'Reddit',
    linkedin: 'LinkedIn',
    snapchat: 'Snapchat',
    pinterest: 'Pinterest',
    whatsapp: 'WhatsApp',
    discord: 'Discord'
  };
  return names[platform] || 'Social Media';
}

currentPlatform = detectPlatform();

// Function to initialize the extension
function init() {
  if (isInitialized || !currentPlatform) return;
  isInitialized = true;

  // Check status immediately
  chrome.runtime.sendMessage({ action: 'checkStatus', platform: currentPlatform }, (response) => {
    if (chrome.runtime.lastError) {
      console.log('Extension context invalidated');
      return;
    }

    if (response.status === 'blocked') {
      showBlockedScreen(response.remainingTime, currentPlatform);
      stopPageInteraction();
    } else if (response.status === 'none') {
      showPurposeDialog(currentPlatform);
      stopPageInteraction();
    } else if (response.status === 'active') {
      sessionStartTime = response.session.startTime;
      timeLimit = response.session.timeLimit;
      if (response.session.timeLimit > 0) {
        startUsageTracking(response.session.startTime, response.session.timeLimit, currentPlatform);
      }
    }
  });
}

// Run init when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function stopPageInteraction() {
  const style = document.createElement('style');
  style.id = 'mindful-hide-content';
  style.textContent = `
    body > *:not(#mindful-overlay):not(#mindful-timer) {
      filter: blur(8px) !important;
      pointer-events: none !important;
      user-select: none !important;
    }
    body {
      overflow: hidden !important;
    }
  `;
  document.head.appendChild(style);
}

function restorePageInteraction() {
  const style = document.getElementById('mindful-hide-content');
  if (style) style.remove();
  document.body.style.overflow = '';
}

function showPurposeDialog(platform) {
  const existing = document.getElementById('mindful-overlay');
  if (existing) existing.remove();

  const platformIcon = getPlatformIcon(platform);
  const platformName = getPlatformName(platform);

  const overlay = document.createElement('div');
  overlay.id = 'mindful-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(255, 255, 255, 0.98);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
  `;

  const dialog = document.createElement('div');
  dialog.style.cssText = `
    background: white;
    padding: 48px;
    border-radius: 16px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
    max-width: 480px;
    width: 90%;
    text-align: center;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.3s ease-out;
  `;

  requestAnimationFrame(() => {
    dialog.style.opacity = '1';
    dialog.style.transform = 'translateY(0)';
  });

  dialog.innerHTML = `
    <div style="margin-bottom: 32px;">
      <div style="font-size: 48px; margin-bottom: 16px;">⏸️</div>
      <h2 style="font-size: 24px; font-weight: 600; color: #1a1a1a; margin: 0 0 12px 0;">
        Take a Moment
      </h2>
      <p style="font-size: 16px; color: #666; margin: 0 0 8px 0; line-height: 1.5;">
        You're about to use <strong>${platformIcon} ${platformName}</strong>
      </p>
      <p style="font-size: 14px; color: #999; margin: 0;">
        Why are you visiting today?
      </p>
    </div>

    <div id="purpose-selection" style="display: none;">
      <div style="display: flex; gap: 12px; margin-bottom: 32px;">
        <button id="purpose-work" class="mindful-btn" style="
          flex: 1;
          padding: 16px 24px;
          font-size: 16px;
          font-weight: 500;
          color: #1a1a1a;
          background: #f5f5f5;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
        ">
          💼 Work
        </button>
        <button id="purpose-leisure" class="mindful-btn" style="
          flex: 1;
          padding: 16px 24px;
          font-size: 16px;
          font-weight: 500;
          color: #1a1a1a;
          background: #f5f5f5;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
        ">
          🎮 Leisure
        </button>
      </div>
    </div>

    <div id="time-selection" style="display: none;">
      <p style="font-size: 14px; color: #666; margin-bottom: 16px;">
        How long do you plan to spend?
      </p>
      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 24px;">
        ${[5, 10, 15, 30, 60, 0].map(t => `
          <button class="time-option mindful-btn" data-time="${t}" style="
            padding: 12px;
            font-size: 14px;
            font-weight: 500;
            color: #1a1a1a;
            background: #f5f5f5;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
          ">${t === 0 ? 'No limit' : t === 60 ? '1 hour' : t + ' min'}</button>
        `).join('')}
      </div>
      <button id="quit-btn" style="
        width: 100%;
        padding: 12px;
        font-size: 14px;
        font-weight: 500;
        color: #999;
        background: #f0f0f0;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.2s;
        margin-top: 8px;
      ">
        ❌ Quit & Leave Site
      </button>
    </div>

    <div id="countdown" style="font-size: 18px; font-weight: 600; color: #666;">
      Please wait: <span id="countdown-timer">10</span>s
    </div>
  `;

  overlay.appendChild(dialog);
  document.documentElement.appendChild(overlay);

  const style = document.createElement('style');
  style.textContent = `
    .mindful-btn:hover {
      background: #e8e8e8 !important;
      border-color: #d0d0d0 !important;
      transform: translateY(-1px);
    }
    .mindful-btn:active {
      transform: scale(0.98) translateY(0);
    }
    .mindful-btn.selected {
      background: #1a1a1a !important;
      color: white !important;
      border-color: #1a1a1a !important;
    }
    #quit-btn:hover {
      background: #e8e8e8 !important;
      border-color: #d0d0d0 !important;
    }
    #quit-btn:active {
      transform: scale(0.98);
    }
  `;
  document.head.appendChild(style);

  let countdown = 10;
  const countdownTimer = document.getElementById('countdown-timer');
  const purposeSelection = document.getElementById('purpose-selection');
  const countdownDiv = document.getElementById('countdown');

  const interval = setInterval(() => {
    countdown--;
    if (countdownTimer) countdownTimer.textContent = countdown;
    
    if (countdown <= 0) {
      clearInterval(interval);
      if (countdownDiv) countdownDiv.style.display = 'none';
      if (purposeSelection) {
        purposeSelection.style.display = 'block';
        purposeSelection.style.opacity = '0';
        requestAnimationFrame(() => {
          purposeSelection.style.transition = 'opacity 0.3s ease';
          purposeSelection.style.opacity = '1';
        });
      }
    }
  }, 1000);

  let selectedPurpose = null;

  document.getElementById('purpose-work').addEventListener('click', (e) => {
    selectedPurpose = 'work';
    e.target.classList.add('selected');
    document.getElementById('purpose-leisure').classList.remove('selected');
    showTimeSelection();
  });

  document.getElementById('purpose-leisure').addEventListener('click', (e) => {
    selectedPurpose = 'leisure';
    e.target.classList.add('selected');
    document.getElementById('purpose-work').classList.remove('selected');
    showTimeSelection();
  });

  function showTimeSelection() {
    const timeSelection = document.getElementById('time-selection');
    purposeSelection.style.display = 'none';
    timeSelection.style.display = 'block';
    
    timeSelection.style.opacity = '0';
    requestAnimationFrame(() => {
      timeSelection.style.transition = 'opacity 0.3s ease';
      timeSelection.style.opacity = '1';
    });
  }

  document.querySelectorAll('.time-option').forEach(button => {
    button.addEventListener('click', () => {
      const selectedTime = parseInt(button.dataset.time);
      startSession(selectedPurpose, selectedTime, overlay, platform);
    });
  });

  // Quit button handler
  document.getElementById('quit-btn').addEventListener('click', () => {
    overlay.remove();
    restorePageInteraction();
    window.location.href = 'about:blank';
  });
}

function startSession(purpose, timeLimitMinutes, overlay, platform) {
  sessionStartTime = Date.now();
  timeLimit = timeLimitMinutes;

  chrome.runtime.sendMessage({
    action: 'startSession',
    purpose: purpose,
    timeLimit: timeLimitMinutes,
    platform: platform
  });

  overlay.remove();
  restorePageInteraction();

  if (timeLimitMinutes > 0) {
    startUsageTracking(sessionStartTime, timeLimitMinutes, platform);
  }
}

function startUsageTracking(startTime, timeLimitMinutes, platform) {
  const endTime = startTime + (timeLimitMinutes * 60 * 1000);
  
  const timer = document.createElement('div');
  timer.id = 'mindful-timer';
  timer.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: rgba(0, 0, 0, 0.85);
    color: white;
    padding: 12px 20px;
    border-radius: 24px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 500;
    z-index: 2147483647;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    transition: opacity 0.3s;
    pointer-events: none;
  `;
  
  document.body.appendChild(timer);

  const updateTimer = () => {
    const now = Date.now();
    const remaining = Math.max(0, Math.ceil((endTime - now) / 1000));
    
    const minutes = Math.floor(remaining / 60);
    const seconds = remaining % 60;
    timer.textContent = `⏱️ ${minutes}:${seconds.toString().padStart(2, '0')} remaining`;

    if (remaining <= 0) {
      clearInterval(countdownInterval);
      endSession(platform);
    }
  };

  updateTimer();
  countdownInterval = setInterval(updateTimer, 1000);
}

function endSession(platform) {
  const now = Date.now();
  const duration = sessionStartTime ? Math.floor((now - sessionStartTime) / 1000) : 0;

  chrome.runtime.sendMessage({
    action: 'blockSocialMedia',
    platform: platform,
    duration: duration
  }, () => {
    location.reload();
  });
}

function showBlockedScreen(remainingSeconds, platform) {
  const existing = document.getElementById('mindful-overlay');
  if (existing) existing.remove();

  const platformIcon = getPlatformIcon(platform);
  const platformName = getPlatformName(platform);

  const overlay = document.createElement('div');
  overlay.id = 'mindful-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    z-index: 2147483647;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;

  const content = document.createElement('div');
  content.style.cssText = `
    text-align: center;
    color: white;
  `;

  content.innerHTML = `
    <div style="font-size: 72px; margin-bottom: 24px;">🔒</div>
    <h1 style="font-size: 32px; font-weight: 600; margin: 0 0 16px 0;">
      Taking a Break
    </h1>
    <p style="font-size: 18px; opacity: 0.9; margin: 0 0 8px 0;">
      ${platformIcon} ${platformName} is blocked for a few minutes
    </p>
    <p style="font-size: 14px; opacity: 0.8; margin: 0 0 32px 0;">
      Time to focus on something else
    </p>
    <div id="block-timer" style="font-size: 48px; font-weight: 700; font-variant-numeric: tabular-nums;">
      ${formatTime(remainingSeconds)}
    </div>
  `;

  overlay.appendChild(content);
  document.documentElement.appendChild(overlay);

  let remaining = remainingSeconds;
  const timerEl = document.getElementById('block-timer');
  
  const interval = setInterval(() => {
    remaining--;
    if (timerEl) timerEl.textContent = formatTime(remaining);
    
    if (remaining <= 0) {
      clearInterval(interval);
      location.reload();
    }
  }, 1000);
}

function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}
