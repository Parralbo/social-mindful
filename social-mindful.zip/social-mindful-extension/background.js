// Background service worker for Social Mindful Usage Extension - Multi-platform

// Initialize storage
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    totalUsageTime: 0,
    platformUsage: {
      facebook: 0,
      instagram: 0,
      tiktok: 0,
      twitter: 0,
      youtube: 0,
      reddit: 0,
      linkedin: 0,
      snapchat: 0,
      pinterest: 0,
      whatsapp: 0,
      discord: 0
    },
    isBlocked: false,
    blockedPlatforms: {},
    currentSessions: {},
    allSessions: []
  });
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkStatus') {
    const platform = request.platform;
    chrome.storage.local.get(['blockedPlatforms', 'currentSessions'], (data) => {
      const now = Date.now();
      const blockedPlatforms = data.blockedPlatforms || {};
      const currentSessions = data.currentSessions || {};

      // Check if platform is blocked
      if (blockedPlatforms[platform] && blockedPlatforms[platform] > now) {
        sendResponse({
          status: 'blocked',
          remainingTime: Math.ceil((blockedPlatforms[platform] - now) / 1000)
        });
        return;
      } else if (blockedPlatforms[platform]) {
        delete blockedPlatforms[platform];
        chrome.storage.local.set({ blockedPlatforms });
      }

      // Check if active session exists
      if (currentSessions[platform]) {
        const session = currentSessions[platform];
        if (session.timeLimit > 0) {
          const sessionEndTime = session.startTime + (session.timeLimit * 60 * 1000);
          if (now > sessionEndTime) {
            // Session expired, block platform
            const blockEndTime = now + (5 * 60 * 1000);
            blockedPlatforms[platform] = blockEndTime;
            delete currentSessions[platform];
            chrome.storage.local.set({ blockedPlatforms, currentSessions });
            sendResponse({
              status: 'blocked',
              remainingTime: 300
            });
            return;
          }
        }

        sendResponse({
          status: 'active',
          session: session
        });
      } else {
        sendResponse({ status: 'none' });
      }
    });
    return true;
  }

  if (request.action === 'startSession') {
    const platform = request.platform;
    const session = {
      platform: platform,
      purpose: request.purpose,
      timeLimit: request.timeLimit,
      startTime: Date.now(),
      endTime: null,
      duration: 0
    };

    chrome.storage.local.get(['currentSessions', 'allSessions'], (data) => {
      const currentSessions = data.currentSessions || {};
      const allSessions = data.allSessions || [];

      currentSessions[platform] = session;
      allSessions.push(session);

      chrome.storage.local.set({
        currentSessions,
        allSessions
      });
    });

    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'endSession') {
    const platform = request.platform;
    const duration = request.duration || 0;

    chrome.storage.local.get(['totalUsageTime', 'platformUsage', 'currentSessions', 'allSessions'], (data) => {
      const totalUsageTime = (data.totalUsageTime || 0) + duration;
      const platformUsage = data.platformUsage || {};
      platformUsage[platform] = (platformUsage[platform] || 0) + duration;

      const currentSessions = data.currentSessions || {};
      const allSessions = data.allSessions || [];

      // Update the current session with end time
      if (currentSessions[platform]) {
        currentSessions[platform].endTime = Date.now();
        currentSessions[platform].duration = duration;
        
        // Update in allSessions array (last session of this platform)
        for (let i = allSessions.length - 1; i >= 0; i--) {
          if (allSessions[i].platform === platform && !allSessions[i].endTime) {
            allSessions[i].endTime = Date.now();
            allSessions[i].duration = duration;
            break;
          }
        }
        
        delete currentSessions[platform];
      }

      chrome.storage.local.set({
        totalUsageTime,
        platformUsage,
        currentSessions,
        allSessions
      });
    });

    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'blockSocialMedia') {
    const platform = request.platform;
    const duration = request.duration || 0;
    const blockEndTime = Date.now() + (5 * 60 * 1000); // 5 minutes

    chrome.storage.local.get(['totalUsageTime', 'platformUsage', 'blockedPlatforms', 'currentSessions', 'allSessions'], (data) => {
      const totalUsageTime = (data.totalUsageTime || 0) + duration;
      const platformUsage = data.platformUsage || {};
      platformUsage[platform] = (platformUsage[platform] || 0) + duration;
      
      const blockedPlatforms = data.blockedPlatforms || {};
      const currentSessions = data.currentSessions || {};
      const allSessions = data.allSessions || [];

      blockedPlatforms[platform] = blockEndTime;

      // Update session end time and duration
      if (currentSessions[platform]) {
        currentSessions[platform].endTime = Date.now();
        currentSessions[platform].duration = duration;
        
        // Update in allSessions
        for (let i = allSessions.length - 1; i >= 0; i--) {
          if (allSessions[i].platform === platform && !allSessions[i].endTime) {
            allSessions[i].endTime = Date.now();
            allSessions[i].duration = duration;
            break;
          }
        }
        
        delete currentSessions[platform];
      }

      chrome.storage.local.set({
        totalUsageTime,
        platformUsage,
        blockedPlatforms,
        currentSessions,
        allSessions
      });
    });

    sendResponse({ success: true });
    return true;
  }

  if (request.action === 'getStats') {
    chrome.storage.local.get(['totalUsageTime', 'platformUsage', 'allSessions'], (data) => {
      let totalUsageTime = data.totalUsageTime || 0;
      const allSessions = data.allSessions || [];
      
      // Calculate total from all sessions if needed
      if (totalUsageTime === 0 && allSessions.length > 0) {
        totalUsageTime = allSessions.reduce((sum, session) => {
          if (session.endTime && session.startTime) {
            return sum + Math.floor((session.endTime - session.startTime) / 1000);
          }
          return sum;
        }, 0);
      }
      
      sendResponse({
        totalUsageTime: totalUsageTime,
        platformUsage: data.platformUsage || {},
        allSessions: allSessions
      });
    });
    return true;
  }
});

// Check block status periodically
chrome.alarms.create('checkBlocks', { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkBlocks') {
    chrome.storage.local.get(['blockedPlatforms'], (data) => {
      const blockedPlatforms = data.blockedPlatforms || {};
      const now = Date.now();
      let updated = false;

      for (const platform in blockedPlatforms) {
        if (blockedPlatforms[platform] <= now) {
          delete blockedPlatforms[platform];
          updated = true;
        }
      }

      if (updated) {
        chrome.storage.local.set({ blockedPlatforms });
      }
    });
  }
});
