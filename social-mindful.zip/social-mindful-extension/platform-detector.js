// Platform detection utility

const PLATFORMS = {
  FACEBOOK: 'facebook',
  INSTAGRAM: 'instagram',
  TIKTOK: 'tiktok',
  TWITTER: 'twitter',
  YOUTUBE: 'youtube',
  REDDIT: 'reddit',
  LINKEDIN: 'linkedin',
  SNAPCHAT: 'snapchat',
  PINTEREST: 'pinterest',
  WHATSAPP: 'whatsapp',
  DISCORD: 'discord'
};

const PLATFORM_ICONS = {
  facebook: '👍',
  instagram: '📷',
  tiktok: '🎵',
  twitter: '𝕏',
  youtube: '▶️',
  reddit: '🔴',
  linkedin: '💼',
  snapchat: '👻',
  pinterest: '📌',
  whatsapp: '💬',
  discord: '🎮'
};

const PLATFORM_COLORS = {
  facebook: '#1877F2',
  instagram: '#E4405F',
  tiktok: '#000000',
  twitter: '#000000',
  youtube: '#FF0000',
  reddit: '#FF4500',
  linkedin: '#0A66C2',
  snapchat: '#FFFC00',
  pinterest: '#E60023',
  whatsapp: '#25D366',
  discord: '#5865F2'
};

function detectPlatform() {
  const hostname = window.location.hostname;

  if (hostname.includes('facebook.com')) {
    return PLATFORMS.FACEBOOK;
  } else if (hostname.includes('instagram.com')) {
    return PLATFORMS.INSTAGRAM;
  } else if (hostname.includes('tiktok.com')) {
    return PLATFORMS.TIKTOK;
  } else if (hostname.includes('twitter.com') || hostname.includes('x.com')) {
    return PLATFORMS.TWITTER;
  } else if (hostname.includes('youtube.com')) {
    return PLATFORMS.YOUTUBE;
  } else if (hostname.includes('reddit.com')) {
    return PLATFORMS.REDDIT;
  } else if (hostname.includes('linkedin.com')) {
    return PLATFORMS.LINKEDIN;
  } else if (hostname.includes('snapchat.com')) {
    return PLATFORMS.SNAPCHAT;
  } else if (hostname.includes('pinterest.com')) {
    return PLATFORMS.PINTEREST;
  } else if (hostname.includes('web.whatsapp.com')) {
    return PLATFORMS.WHATSAPP;
  } else if (hostname.includes('discord.com')) {
    return PLATFORMS.DISCORD;
  }

  return null;
}

function getPlatformIcon(platform) {
  return PLATFORM_ICONS[platform] || '📱';
}

function getPlatformColor(platform) {
  return PLATFORM_COLORS[platform] || '#667eea';
}

function getPlatformName(platform) {
  const names = {
    facebook: 'Facebook',
    instagram: 'Instagram',
    tiktok: 'TikTok',
    twitter: 'Twitter/X',
    youtube: 'YouTube',
    reddit: 'Reddit',
    linkedin: 'LinkedIn',
    snapchat: 'Snapchat',
    pinterest: 'Pinterest',
    whatsapp: 'WhatsApp',
    discord: 'Discord'
  };
  return names[platform] || 'Social Media';
}
