// Popup script for Social Mindful Usage Extension

const PLATFORM_ICONS = {
  facebook: '👍',
  instagram: '📷',
  tiktok: '🎵',
  twitter: '𝕏',
  youtube: '▶️',
  reddit: '🔴',
  linkedin: '💼',
  snapchat: '👻',
  pinterest: '📌',
  whatsapp: '💬',
  discord: '🎮'
};

const PLATFORM_NAMES = {
  facebook: 'Facebook',
  instagram: 'Instagram',
  tiktok: 'TikTok',
  twitter: 'Twitter/X',
  youtube: 'YouTube',
  reddit: 'Reddit',
  linkedin: 'LinkedIn',
  snapchat: 'Snapchat',
  pinterest: 'Pinterest',
  whatsapp: 'WhatsApp',
  discord: 'Discord'
};

document.addEventListener('DOMContentLoaded', () => {
  loadStatistics();
  setupTabs();
  
  document.getElementById('reset-btn').addEventListener('click', resetStatistics);
  
  // Refresh stats every 2 seconds
  setInterval(loadStatistics, 2000);
});

function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.dataset.tab;
      
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      
      tab.classList.add('active');
      document.getElementById(tabName).classList.add('active');
    });
  });
}

function loadStatistics() {
  chrome.runtime.sendMessage({ action: 'getStats' }, (data) => {
    if (!data) return;
    
    // Display total usage time
    const totalSeconds = data.totalUsageTime || 0;
    const totalMinutes = Math.floor(totalSeconds / 60);
    const totalHours = Math.floor(totalMinutes / 60);
    const remainingMinutes = totalMinutes % 60;
    
    const totalTimeEl = document.getElementById('total-time');
    if (totalHours > 0) {
      totalTimeEl.innerHTML = `${totalHours}<span class="stat-unit">h</span> ${remainingMinutes}<span class="stat-unit">min</span>`;
    } else {
      totalTimeEl.innerHTML = `${totalMinutes}<span class="stat-unit">min</span>`;
    }

    // Display platform usage
    const platformUsage = data.platformUsage || {};
    const platformGrid = document.getElementById('platform-grid');
    
    const platformsWithUsage = Object.entries(platformUsage)
      .filter(([_, time]) => time > 0)
      .sort((a, b) => b[1] - a[1]);

    if (platformsWithUsage.length === 0) {
      platformGrid.innerHTML = '<div class="empty-state" style="grid-column: 1/-1;">No usage data yet</div>';
    } else {
      platformGrid.innerHTML = platformsWithUsage.map(([platform, timeInSeconds]) => {
        const minutes = Math.floor(timeInSeconds / 60);
        const icon = PLATFORM_ICONS[platform] || '📱';
        const name = PLATFORM_NAMES[platform] || platform;
        return `
          <div class="platform-item">
            <div class="platform-icon">${icon}</div>
            <div class="platform-name">${name}</div>
            <div class="platform-time">${minutes}m</div>
          </div>
        `;
      }).join('');
    }

    // Display sessions
    const sessions = data.allSessions || [];
    const sessionsContainer = document.getElementById('sessions-container');
    
    if (sessions.length === 0) {
      sessionsContainer.innerHTML = '<div class="empty-state">No sessions yet</div>';
    } else {
      const recentSessions = sessions.slice(-10).reverse();
      
      sessionsContainer.innerHTML = recentSessions.map(session => {
        let duration = 0;
        if (session.endTime && session.startTime) {
          duration = Math.floor((session.endTime - session.startTime) / 1000 / 60);
        } else if (session.duration) {
          duration = Math.floor(session.duration / 60);
        }
        
        const icon = PLATFORM_ICONS[session.platform] || '📱';
        const purposeIcon = session.purpose === 'work' ? '💼' : '🎮';
        const timeLimit = session.timeLimit > 0 ? `${session.timeLimit}m limit` : 'No limit';
        
        return `
          <div class="session-item">
            <div>
              <span class="platform-icon" style="margin-right: 4px;">${icon}</span>
              <span class="session-platform">${purposeIcon} ${session.purpose}</span>
            </div>
            <div class="session-time">${duration}m</div>
          </div>
        `;
      }).join('');
    }

    // Update status
    chrome.storage.local.get(['blockedPlatforms'], (storageData) => {
      const blockedPlatforms = storageData.blockedPlatforms || {};
      const statusIndicator = document.querySelector('.status-indicator');
      const statusText = document.getElementById('status-text');
      
      const blockedCount = Object.keys(blockedPlatforms).length;
      
      if (blockedCount > 0) {
        const now = Date.now();
        let minRemainingTime = Infinity;
        
        for (const platform in blockedPlatforms) {
          const blockTime = blockedPlatforms[platform];
          if (blockTime > now) {
            minRemainingTime = Math.min(minRemainingTime, blockTime - now);
          }
        }
        
        if (minRemainingTime !== Infinity) {
          const remainingSeconds = Math.ceil(minRemainingTime / 1000);
          const mins = Math.floor(remainingSeconds / 60);
          const secs = remainingSeconds % 60;
          
          statusIndicator.classList.remove('active');
          statusIndicator.classList.add('blocked');
          statusText.textContent = `${blockedCount} platform(s) blocked (${mins}:${secs.toString().padStart(2, '0')})`;
        }
      } else {
        statusIndicator.classList.remove('blocked');
        statusIndicator.classList.add('active');
        statusText.textContent = 'Active';
      }
    });
  });
}

function resetStatistics() {
  if (confirm('Are you sure you want to reset all statistics?')) {
    chrome.storage.local.set({
      totalUsageTime: 0,
      platformUsage: {
        facebook: 0,
        instagram: 0,
        tiktok: 0,
        twitter: 0,
        youtube: 0,
        reddit: 0,
        linkedin: 0,
        snapchat: 0,
        pinterest: 0,
        whatsapp: 0,
        discord: 0
      },
      allSessions: [],
      blockedPlatforms: {},
      currentSessions: {}
    }, () => {
      loadStatistics();
    });
  }
}
