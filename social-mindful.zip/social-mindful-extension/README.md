# Social Mindful Usage Extension

A powerful Chrome extension that promotes mindful social media usage across all major platforms by pausing page loads to ask about your purpose, setting time limits, and tracking usage patterns.

## Supported Platforms

The extension works on all these popular social media platforms:

*   **Facebook** - Social networking
*   **Instagram** - Photo and video sharing
*   **TikTok** - Short-form video content
*   **Twitter/X** - Microblogging
*   **YouTube** - Video streaming
*   **Reddit** - Community discussions
*   **LinkedIn** - Professional networking
*   **Snapchat** - Messaging and stories
*   **Pinterest** - Visual discovery
*   **WhatsApp Web** - Web messaging
*   **Discord** - Community chat

## Features

### Purpose Check
When you visit any supported social media platform, the extension pauses the page load for 10 seconds and asks whether you're visiting for **Work** or **Leisure**. This mindful moment helps you stay intentional about your usage.

### Time Limits
After selecting your purpose, you can set a realistic time limit for your session:
*   5 minutes
*   10 minutes
*   15 minutes
*   30 minutes
*   1 hour
*   No limit

### Automatic Blocking
When your time limit expires, the platform is automatically blocked for 5 minutes to encourage a break and help you build better habits.

### Multi-Platform Tracking
The extension tracks your usage across all platforms separately, allowing you to see which platforms consume the most of your time and whether your usage is primarily for work or leisure.

### Usage Statistics
View comprehensive statistics in the extension popup, including:
*   Total usage time across all platforms
*   Per-platform usage breakdown
*   Recent session history
*   Current block status

## Installation

### Step 1: Download and Extract
Download the extension files and extract them to a location on your computer.

### Step 2: Open Chrome Extensions
Open Google Chrome and navigate to `chrome://extensions/` or use the menu: **⋮ > More Tools > Extensions**

### Step 3: Enable Developer Mode
Toggle "Developer mode" in the top-right corner to enable unpacked extension loading.

### Step 4: Load the Extension
Click "Load unpacked" and select the `social-mindful-extension` folder.

### Step 5: Verify Installation
The extension should now appear in your Chrome toolbar. You're ready to use it!

## How It Works

1. **Visit a Social Media Platform** - Navigate to any of the supported platforms
2. **Purpose Dialog Appears** - The extension pauses the page and asks your purpose
3. **Select Purpose & Time Limit** - Choose whether it's work or leisure, and set a time limit
4. **Enjoy Your Session** - A floating timer shows your remaining time
5. **Time Expires** - The platform is blocked for 5 minutes to encourage a break
6. **View Statistics** - Click the extension icon to see your usage patterns

## Privacy

All data is stored locally in your browser using Chrome's storage API. No information is sent to external servers or shared with third parties. Your usage statistics remain completely private on your device.

## Tips for Mindful Usage

*   **Set Realistic Limits** - Choose time limits that match your actual needs
*   **Track Patterns** - Review your statistics regularly to understand your habits
*   **Use the Break** - When blocked, step away from your screen and do something else
*   **Reflect on Purpose** - Each time you're asked, genuinely think about why you're visiting

## Troubleshooting

**Extension Not Appearing**
Ensure the extension is enabled in `chrome://extensions/`. Try disabling and re-enabling it.

**Purpose Dialog Not Showing**
Clear your browser cache and cookies for the specific platform, then refresh the page.

**Statistics Not Updating**
Check that the extension has the necessary permissions in `chrome://extensions/`. Reload the extension if needed.

## Uninstallation

To remove the extension, go to `chrome://extensions/`, find "Social Mindful Usage," and click the "Remove" button.

## Support

For issues or suggestions, please check the extension logs in the browser console or review the extension settings.

---

**Version:** 2.0.0  
**Last Updated:** December 2025  
**License:** MIT
